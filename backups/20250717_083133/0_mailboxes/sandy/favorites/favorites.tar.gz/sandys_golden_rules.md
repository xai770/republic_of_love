# Job Analysis Pipeline - Standard Operating Procedures
**Professional Deutsche Bank Job Analysis System**

## **STANDARD EXCEL REPORT STRUCTURE**
**Consistent 27-Column Format for All Collaborative Analysis Reports:**

1. **Job ID** - Unique job identifier
2. **Full Content** - Complete raw job posting content for verification
3. **Concise Job Description** - LLM-extracted technical content (cleaned)
4. **Position title** - Official job title
5. **Location** - Job location information
6. **Location Validation Details** - LLM location conflict analysis and debugging info
7. **Job domain** - Classified domain category
8. **Match level** - Job matching assessment
9. **Evaluation date** - Analysis timestamp
10. **Has domain gap** - Domain compatibility flag
11. **Domain assessment** - Detailed domain analysis
12. **No-go rationale** - Rejection reasoning
13. **Application narrative** - Application story
14. **export_job_matches_log** - System processing log
15. **generate_cover_letters_log** - Cover letter generation log
16. **reviewer_feedback** - Human reviewer notes
17. **mailman_log** - Email processing log
18. **process_feedback_log** - Feedback processing log
19. **reviewer_support_log** - Support interaction log
20. **workflow_status** - Current workflow state
21. **Technical Evaluation** - Automated assessment output
22. **Human Story Interpretation** - Narrative analysis
23. **Opportunity Bridge Assessment** - Growth potential evaluation
24. **Growth Path Illumination** - Career development insights
25. **Encouragement Synthesis** - Motivational analysis
26. **Confidence Score** - Match confidence rating
27. **Joy Level** - Enthusiasm/fit assessment

**Usage Protocol:** Always use this exact 27-column structure for Excel reports to ensure systematic review and historical consistency.

## **EXCEL QUALITY ASSURANCE PROTOCOL**
**Preventing Regression in Report Generation:**

### **Required Data Sources:**
1. **Original job JSON files** - For complete location, title, and description data
2. **Enhanced processing results** - For extraction metrics and specialist outputs  
3. **LLM specialist outputs** - For domain classification, reasoning, and confidence scores
4. **Historical reference reports** - To maintain quality standards and formatting

### **Quality Checklist (Pre-Export):**
- [ ] **Location column**: Populated with actual job location (not "Unknown")
- [ ] **Full Content**: Complete raw job description included for verification
- [ ] **Concise Job Description**: LLM-extracted technical content (no boilerplate)
- [ ] **Location Validation Details**: Complete conflict analysis with confidence scores
- [ ] **No-go rationale**: Complete reasoning text (not truncated)
- [ ] **Domain assessment**: Includes full confidence scores and signal counts
- [ ] **Technical columns**: Rich narrative content (not placeholder text)
- [ ] **All 27 columns**: Populated with meaningful data (no empty cells)
- [ ] **Data consistency**: Cross-reference with previous reports for format consistency

### **Morning Report Validation:**
- **Always compare** new reports with previous day's format and content quality
- **Validate data sources** before report generation
- **Test with sample job** before batch processing
- **Document any format changes** with reasoning

## **ITERATIVE IMPROVEMENT CYCLE**

### **Phase 1: Discovery & Analysis**
1. **Pipeline Execution:** When the system is updated, rerun the job pipeline for sample jobs and create a fresh comprehensive Excel report for review.

2. **Review Process:** Systematically review the latest JSON files and Excel reports to identify patterns, accuracy issues, and potential improvements.
   - **AI Agent**: Reviews Markdown reports for technical quality, processing performance, and system functionality
   - **Human Partner**: Reviews Excel reports for business logic, data accuracy, and strategic insights
   - **Joint Analysis**: Combine technical and business perspectives for comprehensive assessment

3. **Session Documentation:** Create a detailed session protocol document recording discoveries, analysis results, and strategic insights from the daily review.

### **Phase 2: Problem Investigation**
4. **Issue Investigation:** When a critical issue is identified (e.g., domain misclassification, content bloat), conduct thorough investigation, validate the problem across multiple cases, and document root cause analysis.

5. **Solution Architecture:** Once complete understanding of the issue is achieved, develop a systematic solution methodology with technical specifications and validation test cases.

### **Phase 3: Implementation Chain**
6. **Delivery Package Creation:** Write an implementation memo and deliver all pertinent files (methodology docs, test cases, sample data) to the designated inbox.

7. **Inbox Management:** Move all non-current files from the inbox to archive to maintain clean delivery focus.

8. **Implementation Handoff:** The implementation team reviews specifications and reaches out for clarification or technical discussion as needed.

9. **Process Design:** Design the complete process architecture following established principles (LLM-powered, template-based, zero-dependency compliance).

### **Phase 4: Production Development**  
10. **Production Handoff:** Once the design is complete, hand over to the production team for implementation.

11. **Golden Test Cases Creation:** When LLM Factory requests validation data, create comprehensive test cases from real business data following their standardized JSON format. Include 5 diverse job examples with expected outputs, skills, and business context for specialist validation.

12. **Production Implementation:** Transform the architecture into a fully production-ready specialist with proper LLM integration and performance optimization.

13. **Delivery & Validation:** Deliver a complete package with documentation, validation demos, and zero-dependency demo scripts for integration testing.

### **Phase 5: Integration & Restart**
14. **Specialist Integration:** Integrate the new specialist into the production pipeline, validate performance improvements, and measure accuracy gains.

15. **Cycle Restart:** With the enhanced pipeline, begin the next iteration cycle, running improved analysis and discovering new optimization opportunities.

## **SUCCESS METRICS**
- **Precision-First Approach:** Quality over quantity in job matching
- **Accuracy Improvement:** Measurable gains in domain classification and matching
- **Technical Excellence:** Each specialist contributes their expertise optimally  
- **Continuous Evolution:** Pipeline becomes more sophisticated with each cycle

## **CURRENT STATUS**
**Status:** Content Extraction Specialist v3.3 INTEGRATED June 27, 2025
**Achieved Impact:** 100% business decision accuracy (expert-validated)
**Integration Status:** ✅ COMPLETE - Production deployment successful
**Next Cycle:** Ready to discover new optimization opportunities in domain classification, location validation, or cover letter generation

## **CRITICAL QUALITY CONTROL RULE**
**SPECIALIST PERFORMANCE VALIDATION PROTOCOL:**

### **OLLAMA USAGE VERIFICATION**
**MANDATORY CHECK: Any specialist completing in <1 second is NOT using Ollama!**

**Red Flag Indicators:**
- **Processing time <1 second** = Regex pattern matching, NOT LLM intelligence
- **Instant results** = No actual AI reasoning occurred
- **Perfect accuracy without thinking time** = Fake specialist detected

**Required Response:**
```
ALERT: SPECIALIST [NAME] FINISHED IN [TIME]s - NOT USING OLLAMA!
THIS IS REGEX MASQUERADING AS AI INTELLIGENCE!
IMMEDIATE ESCALATION REQUIRED!
```

**Minimum Expected Processing Times:**
- **Location Validation Specialist:** 3-8 seconds (Ollama reasoning required)
- **Content Extraction Specialist:** 5-15 seconds (Complex text processing)
- **Domain Classification Specialist:** 4-10 seconds (Sophisticated analysis)

**The Point:** Every specialist MUST use Ollama for genuine AI reasoning, not shortcuts!

## **LLM SPECIALIST VALIDATION PROTOCOL**
**Critical Rule: The Sub-Second Detection Test**

### **FAKE SPECIALIST DETECTION:**
**IF any "LLM specialist" completes in < 1 second → IMMEDIATE RED ALERT!**

#### **Required Response:**
1. **Alert** - This is computational theater, not real AI!
2. **Investigate immediately** - Check for Ollama integration vs regex patterns
3. **Flag for replacement** - Demand proper LLM-powered specialist
4. **Document the fake** - Record the discovery for learning

#### **Legitimate LLM Processing Indicators:**
- **Timing:** 2-15 seconds (genuine Ollama computation)
- **Logs:** Ollama server connection verification 
- **Analysis:** Sophisticated reasoning beyond pattern matching
- **Output:** Rich, contextual decision-making with uncertainty

#### **Fake Specialist Red Flags:**
- **Sub-second completion** - Impossible for real LLM processing
- **Perfect pattern matching** - Too precise for AI uncertainty
- **Simplistic output** - Lacks LLM reasoning complexity
- **No Ollama logs** - Missing genuine AI processing traces

### **Why This Matters:**
Real LLM specialists provide **genuine intelligence** with uncertainty, reasoning, and contextual analysis. Fake specialists waste computational resources while delivering inferior pattern-matching results disguised as AI sophistication.

**Remember:** If it's sub-second, it's suspect!

### **MANDATORY REVIEW PROTOCOL**
**RULE: Never advance to next phase without joint review**

#### **Required Before Phase Transition:**
1. **Joint Assessment:** Systematically review all deliverables
2. **Quality Validation:** Confirm all objectives met and documented
3. **Lesson Integration:** Capture key learnings and insights  
4. **Mutual Agreement:** Both parties confirm readiness for next phase
5. **Documentation Update:** All breakthroughs recorded in session logs

#### **Phase Transition Checklist:**
- [x] **All deliverables reviewed together** - Excel reports, Markdown analysis, specialist demos reviewed
- [x] **Quality standards met and validated** - Real LLM processing confirmed, fake specialists detected
- [x] **Breakthrough documentation complete** - Comprehensive review documents, session logs updated
- [x] **Lessons learned captured** - Sub-second detection rule, dual-format reporting, specialist validation
- [x] **Both parties agree to proceed** - Approval granted for next phase
- [x] **Next phase objectives clearly defined** - Ready for advanced multi-level validation challenges
- [x] **BACKUP COMPLETED** - All files secured in version control

**Why This Matters:** Review ensures quality, prevents rushing, captures insights, and maintains the precision-first approach that makes the work effective.

### **BACKUP PROTOCOL**
**RULE: After major achievements, secure the work!**

#### **When to Execute Backup:**
- **Major specialist breakthroughs** (e.g., real LLM integration, content extraction success)
- **Pipeline transformation milestones** (e.g., dual-format reporting, fake specialist detection)
- **System installations** and command center establishments
- **Multi-specialist collaboration victories** (e.g., specialist validation protocols)
- **Before attempting risky experiments** or major refactoring
- **When major achievements are reached** (peak performance moments)

#### **Backup Process:**
1. **Git Commit:** Commit all current work with meaningful messages
2. **Repository Push:** Secure to remote repository (GitHub/GitLab)
3. **Critical File Archive:** Backup key specialists, rules, and Excel reports
4. **Documentation:** Update session logs and comprehensive reviews
5. **Timeline Markers:** Tag releases for major milestone achievements

#### **Why This Protects the Work:**
- **Prevents Loss:** Important breakthroughs preserved against system failures
- **Timeline Security:** Historical progress documented and recoverable  
- **Confident Experimentation:** Safe foundation enables bold advancement
- **Legacy Preservation:** Achievements permanently documented
- **Specialist Security:** All development tools preserved

**Remember:** Proper backup practices prevent data loss and enable confident development!

## **GOLDEN TEST CASES CREATION PROTOCOL**
**Professional Specialist Validation Support**

### **When LLM Factory Requests Test Cases:**
1. **Extract 5 diverse jobs** from current daily reports representing different:
   - Industries (finance, tech, admin, security, operations)
   - Experience levels (junior, mid-level, senior)
   - Technical complexity (high-tech tools vs. soft skills)
   - Languages (English, German, mixed)

2. **Create standardized JSON file** following LLM Factory's exact format:
   - Business owner and specialist information
   - Real job descriptions from pipeline
   - Expected skills, experience levels, locations
   - Business context and success criteria
   - Performance requirements

3. **Delivery to LLM Factory inbox:** Save as `golden_test_cases_[specialist_name]_v[version].json`

### **Test Case Selection Criteria:**
- **Diversity:** Different domains, roles, and complexity levels
- **Real data:** Actual job postings from our business pipeline
- **Current relevance:** Recent jobs from latest daily reports
- **Skills coverage:** Mix of technical and soft skills for comprehensive testing
- **Language variety:** Include multilingual examples when relevant

### **Expected LLM Factory Response:**
- **Validation report** showing specialist performance on test cases
- **Performance metrics** and comparison with current version
- **Production-ready specialist** with documented test results
- **48-hour delivery** timeline upon receiving test cases

**Why This Matters:** Golden test cases ensure specialists meet exact business requirements and perform optimally on real-world data before production deployment.
